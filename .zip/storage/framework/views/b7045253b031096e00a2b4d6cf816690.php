<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
            Data Transaksi
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-10">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg p-6">

                
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200">List Transaksi</h3>
                    <a href="<?php echo e(route('transaksi.create')); ?>"
                       class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md shadow">
                        ➕ Tambah Transaksi
                    </a>
                </div>

                
                <div class="flex justify-between mb-4 flex-col md:flex-row gap-4">
                    <form method="GET" action="<?php echo e(route('transaksi.index')); ?>" class="flex flex-wrap gap-2 items-end">
                        
                        <div>
                            <label class="text-sm text-gray-600 dark:text-gray-300">Status Pembayaran</label>
                            <select name="status" class="form-select rounded-md shadow-sm">
                                <option value="">-- Semua --</option>
                                <option value="Lunas" <?php echo e(request('status') == 'Lunas' ? 'selected' : ''); ?>>Lunas</option>
                                <option value="Belum Lunas" <?php echo e(request('status') == 'Belum Lunas' ? 'selected' : ''); ?>>Belum Lunas</option>
                            </select>
                        </div>

                        
                        <div>
                            <label class="text-sm text-gray-600 dark:text-gray-300">Nama Dokter</label>
                            <select name="dokter_id" class="form-select rounded-md shadow-sm">
                                <option value="">-- Semua Dokter --</option>
                                <?php $__currentLoopData = $dokters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dokter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dokter->id); ?>" <?php echo e(request('dokter_id') == $dokter->id ? 'selected' : ''); ?>>
                                        <?php echo e($dokter->nama); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        
                        <button type="submit" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md shadow">
                            🔍 Filter
                        </button>

                        
                        <a href="<?php echo e(route('transaksi.cetak')); ?>" target="_blank"
                           class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md shadow">
                            🖨️ Cetak Semua
                        </a>

                        
                        <a href="<?php echo e(route('transaksi.print.filter', ['status' => request('status'), 'dokter_id' => request('dokter_id')])); ?>"
                           target="_blank"
                           class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md shadow">
                            🖨️ Cetak Hasil Filter
                        </a>
                    </form>
                </div>

                
                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                        <thead class="bg-gray-100 dark:bg-gray-700">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">ID</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Nama Dokter</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Jenis Gigi</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Jumlah</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Ongkir</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Total Harga</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Tgl Selesai</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Status</th>
                                <th class="px-6 py-3 text-right text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                            <?php $__empty_1 = true; $__currentLoopData = $transaksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="px-6 py-4 text-sm text-gray-900 dark:text-white"><?php echo e($item->id); ?></td>
                                    <td class="px-6 py-4 text-sm text-gray-900 dark:text-white"><?php echo e($item->dokter->nama ?? '-'); ?></td>
                                    <td class="px-6 py-4 text-sm text-gray-900 dark:text-white"><?php echo e($item->jenisGigi->nama ?? '-'); ?></td>
                                    <td class="px-6 py-4 text-sm text-gray-900 dark:text-white"><?php echo e($item->jumlah); ?></td>
                                    <td class="px-6 py-4 text-sm text-gray-900 dark:text-white">Rp<?php echo e(number_format($item->ongkir, 0, ',', '.')); ?></td> <!-- Kolom Ongkir -->
                                    <td class="px-6 py-4 text-sm text-gray-900 dark:text-white">Rp<?php echo e(number_format($item->total_harga, 0, ',', '.')); ?></td>
                                    <td class="px-6 py-4 text-sm text-gray-900 dark:text-white">
                                        <?php echo e($item->tgl_selesai ? \Carbon\Carbon::parse($item->tgl_selesai)->format('d-m-Y') : '-'); ?>

                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-900 dark:text-white">
                                        <span class="inline-block px-2 py-1 text-xs font-semibold rounded
                                            <?php echo e($item->status_pembayaran === 'Lunas' ? 'bg-green-200 text-green-800' : 'bg-yellow-200 text-yellow-800'); ?>">
                                            <?php echo e($item->status_pembayaran ?? '-'); ?>

                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-sm text-right">
                                        <div class="flex justify-end space-x-2">
                                            <a href="<?php echo e(route('transaksi.nota', $item->id)); ?>"
                                               target="_blank"
                                               class="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-md text-xs font-medium shadow">
                                                🧾 Nota
                                            </a>
                                            <a href="<?php echo e(route('transaksi.edit', $item->id)); ?>"
                                               class="bg-yellow-500 hover:bg-yellow-600 text-white px-3 py-1 rounded-md text-xs font-medium shadow">
                                                ✏️ Edit
                                            </a>
                                            <form action="<?php echo e(route('transaksi.destroy', $item->id)); ?>" method="POST"
                                                  onsubmit="return confirm('Yakin ingin menghapus?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"
                                                        class="bg-red-600 hover:bg-red-700 text-white px-3 py-1 rounded-md text-xs font-medium shadow">
                                                    🗑️ Hapus
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center px-6 py-4 text-sm text-gray-500 dark:text-gray-300">
                                        Belum ada data transaksi.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\lampungdental\resources\views/transaksi/index.blade.php ENDPATH**/ ?>